
<div class="foornav">
	<a href="<?php echo $aik['pcdomain']?>"><span><img src="images/index.png"/>首页</span></a>
	<a href="./movie.php?page=1"><span><img src="images/video.png"/>影片</span></a>
	<a href="./top.php"><span><img src="images/dianshi.png"/>热搜榜</span></a>
	<a href="./dh.php"><span><img src="images/dianshiju.png"/>其他</span></a>
	<?php echo $aik['end_ad'];?>
</div>
<footer class="footer">
<div class="branding branding-black">
	<div class="container" style="text-align: center;">
		<h2><?php echo $aik['sitename'];?> - 海量高清视频在线观看</h2>
<?php echo $aik['youlian'];?>
			</div>
</div>


<p style="padding: 0 4px;"><?php echo $aik['foot'];?><br/>管理员邮箱：<?php echo $aik['admin_email'];?><br/>&copy;  <a href="<?php echo $aik['pcdomain'];?>"><?php echo $aik['sitename'];?></a>&nbsp; <a href="https://zhiyun66.github.io/htm/index.html"><?php echo $aik['icp'];?></a>&nbsp; 
        本站主题由 <?php echo $aik['sitename'];?> 提供 &nbsp; <div style="display: none"><?php echo $aik['tongji'];?></div> 
        </footer>
	<div class="rewards-popover-mask" etap="rewards-close"></div>
	<div class="rewards-popover">
		<h3>觉得本站还不错就打赏一下吧！</h3>
				<div class="rewards-popover-item">
			<h4>支付宝扫一扫打赏</h4>
			<?php echo $aik['zfb_ad'];?>
		</div>
						<div class="rewards-popover-item">
			<h4>微信扫一扫打赏</h4>
			<?php echo $aik['wx_ad'];?>
		</div>
				<span class="rewards-popover-close" etap="rewards-close"></span>
	</div> 
<script type='text/javascript' src='js/main.js'></script>
